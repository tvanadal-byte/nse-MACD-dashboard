import yfinance as yf
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from datetime import datetime, timedelta
import os

os.makedirs('macd_output/charts', exist_ok=True)
tickers = pd.read_csv('tickers.csv')
if 'Symbol' in tickers.columns:
    symbols = tickers['Symbol'].dropna().unique().tolist()
else:
    symbols = tickers.iloc[:,0].dropna().unique().tolist()

def calculate_indicators(df):
    df['EMA12'] = df['Close'].ewm(span=12, adjust=False).mean()
    df['EMA26'] = df['Close'].ewm(span=26, adjust=False).mean()
    df['MACD'] = df['EMA12'] - df['EMA26']
    df['Signal'] = df['MACD'].ewm(span=9, adjust=False).mean()
    df['Histogram'] = df['MACD'] - df['Signal']
    delta = df['Close'].diff()
    gain = np.where(delta > 0, delta, 0)
    loss = np.where(delta < 0, -delta, 0)
    avg_gain = pd.Series(gain).rolling(14).mean()
    avg_loss = pd.Series(loss).rolling(14).mean()
    rs = avg_gain / avg_loss
    df['RSI'] = 100 - (100 / (1 + rs))
    low_min = df['Low'].rolling(14).min()
    high_max = df['High'].rolling(14).max()
    df['ADX'] = 100 * abs((df['High'] - df['Low']).diff() / (high_max - low_min))
    df = df.dropna()
    return df

bullish_list = []

for sym in symbols:
    try:
        data = yf.download(f"{sym}.NS", period='6mo', interval='1d', progress=False)
        if data.empty:
            continue
        df = calculate_indicators(data)
        latest = df.iloc[-1]
        prev = df.iloc[-2]
        if prev['MACD'] < prev['Signal'] and latest['MACD'] > latest['Signal']:
            bullish_list.append(sym)
        plt.figure(figsize=(10,6))
        plt.title(f"{sym} - MACD, RSI, ADX")
        plt.plot(df.index, df['Close'], label='Close Price', color='black')
        plt.plot(df.index, df['MACD'], label='MACD', color='blue')
        plt.plot(df.index, df['Signal'], label='Signal', color='red')
        plt.bar(df.index, df['Histogram'], label='Histogram', color='gray')
        plt.legend()
        plt.savefig(f'macd_output/charts/{sym}.png')
        plt.close()
    except Exception as e:
        print(f"Error for {sym}: {e}")

pd.DataFrame({'Bullish_Stocks': bullish_list}).to_csv('macd_output/bullish_list.csv', index=False)
print(f"Run completed. {len(bullish_list)} bullish stocks found.")
