import streamlit as st
import pandas as pd
import os

st.set_page_config(page_title='NSE MACD Dashboard', layout='wide')

st.title('📈 NSE MACD, RSI, and ADX Dashboard')

bullish_path = 'macd_output/bullish_list.csv'
charts_path = 'macd_output/charts'

if os.path.exists(bullish_path):
    bullish_df = pd.read_csv(bullish_path)
    st.subheader('🚀 Bullish Crossover Stocks (MACD Signal)')
    st.dataframe(bullish_df)
else:
    st.warning('No bullish data found yet. Please wait for the daily update to run.')

if os.path.exists(charts_path):
    all_charts = sorted(os.listdir(charts_path))
    selection = st.selectbox('Select a stock chart:', all_charts)
    st.image(os.path.join(charts_path, selection), use_container_width=True)
else:
    st.info('Charts will appear here after the first data update.')
